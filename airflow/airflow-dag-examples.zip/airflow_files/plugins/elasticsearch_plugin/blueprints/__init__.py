from elasticsearch_plugin.blueprints.elasticsearch_blueprint import ElasticsearchBlueprint

ELASTICSEARCH_PLUGIN_BLUEPRINTS = [
	ElasticsearchBlueprint
]
