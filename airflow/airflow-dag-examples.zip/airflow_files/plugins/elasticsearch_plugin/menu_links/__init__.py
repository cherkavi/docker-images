from elasticsearch_plugin.menu_links.elasticsearch_link import ElasticsearchLink

ELASTICSEARCH_PLUGIN_LINKS = [
	ElasticsearchLink
]
