from flask_admin.base import MenuLink

ElasticsearchLink = MenuLink(category='Elasticsearch Plugin', name='More Info', url='https://marclamberti.com')
